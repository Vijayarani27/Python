import Day3factorial as factorial
fact = factorial.Factorial()
print("Inside Module")
fact.fun(5)
